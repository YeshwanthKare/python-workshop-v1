num1 = int(input("Enter First number: "))
num2 = int(input("Enter Second number: "))

print(type(num1))
print(type(num2))

sum = num1 + num2

print("Sum of numbers", sum)

diff_of_num = num1 - num2

print("Diff of numbers", diff_of_num)

prod_of_num = num1 * num2

print("Prod of numbers", prod_of_num)

div_of_num = num1 / num2

print("Div of numbers", div_of_num)