name=input("enter your name: ")
name = "John" # Variable = can be varied
env = "dev" # dev = constant
print("Hello", name)